//
// XMLFilter.cpp
//
// Library: XML
// Package: SAX
// Module:  SAXFilters
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/SAX/XMLFilter.h"


namespace Poco {
namespace XML {


XMLFilter::~XMLFilter()
{
}


} } // namespace Poco::XML
